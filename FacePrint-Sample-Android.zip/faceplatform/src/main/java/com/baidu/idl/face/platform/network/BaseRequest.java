package com.baidu.idl.face.platform.network;

/**
 * 网络请求基类
 */
public class BaseRequest {
}
