package com.baidu.idl.face.platform;

/**
 * 活体动作枚举类型
 */
public enum LivenessTypeEnum {
    Eye,
    Mouth,
    HeadLeft,
    HeadRight,
    HeadLeftOrRight,
    HeadUp,
    HeadDown
}
